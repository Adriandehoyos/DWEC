export interface IproductInterfaces {
  sku: string,
  title: string,
  price: string;


}
