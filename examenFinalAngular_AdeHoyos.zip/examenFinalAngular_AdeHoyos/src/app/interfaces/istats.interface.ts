export interface Istats {
    genjutsu:     number;
    handseals:    number;
    id:           number;
    intelligence: number;
    ninjutsu:     number;
    speed:        number;
    stamina:      number;
    strength:     number;
    taijutsu:     number;
}
