export interface Auth {
    username: string,
    password: string,
}
